package 포트폴리오;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;

import Test.UserInfo;

public class UserUpdate {
	JFrame frame;
	JButton[] btn;
	JPanel[] panel;
	JTable table; 
	JLabel[] label;
	JTextField[] text;

	
	public UserUpdate() {
		frame = new JFrame();
		btn = new JButton[3];
		btn[0] = new JButton("수정");
		btn[1] = new JButton("계정삭제");
		btn[2] = new JButton("홈");
		label = new JLabel[] {
				new JLabel("이름")
				,new JLabel("id")
				,new JLabel("password")
				,new JLabel("password확인")
				,new JLabel("이메일")
				,new JLabel("전화번호")
				,new JLabel("생년월일")
				,new JLabel("사원번호")};
		text = new JTextField[] {
				new JTextField()
				,new JTextField()
				,new JTextField()
				,new JTextField()
				,new JTextField()
				,new JTextField()
				,new JTextField()
				,new JTextField()};
		panel = new JPanel[] {
				new JPanel(),
				new JPanel()
		};
	}
	public void show(ArrayList<UserInfo> userinfo) {
		//panel[0]
		panel[0].setBounds(0, 0, 600, 60);
		panel[0].setLayout(null);
		
		panel[0].add(btn[0]);
		btn[0].setBounds(10, 10, 60, 50);
		panel[0].add(btn[1]);
		btn[1].setBounds(80, 10, 60, 50);
		panel[0].add(btn[2]);
		
		btn[2].setBounds(150, 10, 60, 50);
		btn[2].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		
		//panel[1]
		panel[1].add(panel[0]);
		panel[1].add(panel[1]);
		panel[1].add(label[0]);
		panel[1].add(text[0]);
		panel[1].add(label[1]);
		panel[1].add(text[1]);
		panel[1].add(label[2]);
		panel[1].add(text[2]);
		panel[1].add(label[3]);
		panel[1].add(text[3]);
		panel[1].add(label[4]);
		panel[1].add(text[4]);
		panel[1].add(label[5]);
		panel[1].add(text[5]);
		panel[1].add(label[6]);
		panel[1].add(text[6]);
		panel[1].add(label[7]);
		panel[1].add(text[7]);
		
		
		//frame 셋팅
		frame.add(panel[0]);
		frame.add(panel[1]);
		frame.setVisible(true);
		frame.setSize(600, 400);
		frame.setLayout(new GridLayout(2,1));
	}
}
